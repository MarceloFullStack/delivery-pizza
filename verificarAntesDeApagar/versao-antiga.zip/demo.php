<link href="css/home.css" rel="stylesheet" type="text/css" />

<div class="box69" id="demo" style="display:none;">

  <div class="box35">Ops!</div>

  <div class="box36">Esta função está desativada</div>

  

  <div class="box70">

    <div class="box71"><img src="arquivos/logo_mais.jpg" width="160" height="165" /></div>

    <div class="box72">

      <div class="box73">Esta é apenas uma</div>

      <div class="box74">Demonstração do Sistema</div>

      <div class="box75">Quer ter um site como este? <span>Entre em contato</span></div>

      <div class="box100">httpss://www.facebook.com/messias.jose.1</div>

      <div class="box99">(31) 8703 - 6429</div>

      <div class="box76">https://www.avinci.com.br</div>

    </div>

  </div>

  <div class="box112">

    <div class="box113">Quer saber mais sobre o sistema de Pedidos online para Pizzarias?</div>

    <a href="https://www.avinci.com.br/pedpizza" target="_blank">

    <div class="box114">CLIQUE AQUI</div></a>

  </div>

</div>



