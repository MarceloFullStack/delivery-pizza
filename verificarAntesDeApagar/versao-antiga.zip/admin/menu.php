

<ul>

    <li class="active"><a href="../admin"><span><img src="arquivos/dashboard.png"> Início</span></a></li>

   

   

  

  <li class="dropdown"><a href=""><span><img src="arquivos/chart.png"> Pizzas</span></a>

        <ul>

        <li><a href="cadastro_pizza.php">Cadastrar Pizza</a></li>

        <li><a href="cadastro_tamanho.php">Cadastrar Tamanho</a></li>

        <li><a href="cadastro_sabores.php">Cadastrar Sabor</a></li>

        <li><a href="fotos_pizzas.php">Fotos Pizzas</a></li>

        <li><a href="produtos.php">Cadastros</a></li>

        </ul>

    </li> 

  

	

    <li class="dropdown"><a href=""><span><img src="arquivos/chart.png"> Outros Produtos</span></a>

        <ul>

        <li><a href="cadastro_produtos.php">Cadastrar Produto.</a></li>

        <li><a href="fotos_produtos.php">Fotos Produtos</a></li>

        <li><a href="produtos2.php">Cadastros</a></li>

        </ul>

    </li>

   

    

     <li class="dropdown"><a href=""><span><img src="arquivos/chart.png"> Pedidos</span></a>

        <ul>

        <li><a href="aberto.php">Pedidos em Aberto</a></li>

        <li><a href="aprovados.php">Pedidos Aprovados</a></li>

        <li><a href="preparo.php">Pedidos no Forno</a></li>

        <li><a href="enviados.php">Pedidos Enviados</a></li>

        <li><a href="finalizados.php">Pedidos Finalizados</a></li>

        <li><a href="cancelados.php">Pedidos Cancelados</a></li>

        </ul>

    </li>

    <li><a href="ingredientes.php"><span><img src="arquivos/chart.png"> Ingredientes</span></a> </li> 

    <li><a href="bordas.php"><span><img src="arquivos/chart.png"> Bordas</span></a> </li> 

    <li><a href="cadastro_categorias.php"><span><img src="arquivos/chart.png"> Categorias</span></a> </li> 

    <li><a href="clientes.php"><span><img src="arquivos/chart.png"> Clientes</span></a> </li> 

    

    <li><a href="cidades.php"><span><img src="arquivos/chart.png"> Cidades/Bairros</span></a></li>

    

 <li class="dropdown"><a href=""><span><img src="arquivos/chart.png"> Entregadores</span></a>

        <ul>

        <li><a href="cadastro_entregador.php">Cadastrar</a></li>

        <li><a href="entregadores.php">Cadastrados</a></li>

        </ul>

    </li>

    

    <li class="dropdown"><a href=""><span><img src="arquivos/chart.png"> Configurações</span></a>

        <ul>

        <li><a href="config.php">Configurações</a></li>

        <li><a href="slides.php">Slide Home</a></li>

        </ul>

    </li>



    <li><a href="alterar_senha.php"><span><img src="arquivos/chart.png"> Alterar Senha</span></a></li>

    <li><a href="notificacoes.php"><span><img src="arquivos/chart.png"> Enviar Notificação</span></a></li>
</ul>