﻿<?php

include('bd.php');


$conf=mysql_query("SELECT * FROM config");

$config=mysql_fetch_assoc($conf);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="https://www.w3.org/1999/xhtml">

<head>

<meta https-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Fechado Para Pedidos</title>

<link rel="stylesheet" media="(min-width: 640px)" href="css/home.css">

</head>



<body>

	<script>
(function(window, document, undefined){
  'use strict';

  document.addEventListener('DOMContentLoaded', function(event) {
    var time = 15;
    var $timeLeft = document.getElementById('timeLeft');

    $timeLeft.innerHTML = time;

    var itv = setInterval(function(){
      $timeLeft.innerHTML = time--;

      if (time === 0) {
        clearTimeout(itv);
        location.href = '/';
      }
    }, 1000);
  });
}(window, document));
</script>

<p>Atualizado o Status em <span id="timeLeft"></span> segundos.</p>

<div class="box2017">

  <div class="box2018" style="height: 102px;"><a href="/"><img src="/admin/logo/<?php echo $config['logomarca']; ?>" style="width: 233px;"/></a></div>

  <div class="box2019" style="width: 100%; font-size: 45px;">Estamos Fechados Para Pedidos</div>
  <a href="montar"><div class="box2019" style="width: auto; font-size: 32px; color: #d62020;">Clique aqui para Para Visualizar Nosso Cardapio, Porem Não Conseguirá fazer o pedido!</div></a>

</div>

</body>

</html>

