<?php if (!session_id()) session_start();?>
<?php



	session_unset();
//desloga gmail se houver ...
?>
<script src="https://apis.google.com/js/client:platform.js?onload=renderButton" async defer></script>
<meta name="google-signin-client_id" content="533763365324-thurvulivcbot4i62rmg56d9chab25dc.apps.googleusercontent.com">
<script>
// Render Google Sign-in button
function renderButton() {
    gapi.signin2.render('gSignIn', {
        'scope': 'profile email',
        'width': 240,
        'height': 39,
        'longtitle': true,
        'theme': 'dark',
        'onsuccess': onSuccess,
        'onfailure': onFailure
    });
	/*
    var auth2 = gapi.auth2.getAuthInstance();
	if(auth2!=null){
		auth2.signOut().then(function () {
		});
		auth2.disconnect();
	}
	window.location='/';*/
	gapi.client.load("oauth2","v2",function(){
		var request=gapi.client.oauth2.userinfo.get({
			"userId":"me"
		});
		request.execute(function (resp){
			signOut();
		});
	});
}
function onSuccess(googleUser){
}
function onFailure(error){
	alert(error);
}
// Sign out the user
function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
    });
    auth2.disconnect();
	window.location='/';
}
</script>
<div id="gSignIn" style="display:none"></div>
<div class="userContent" style="display: none;"></div>			
<?php
?>