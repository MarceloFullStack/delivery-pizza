<?php
$cs_status1 = "Pedido Aceito";
$cs_status2 = "Pedido Recusado";
$cs_status3 = "Saiu para entrega";
$cs_status4 = "Devolvido";
$cs_status5 = "Endereço irregular";
$cs_status6 = "Erro operacional";
?>