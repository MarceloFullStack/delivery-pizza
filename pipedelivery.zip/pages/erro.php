<?php
logs("Tentou acessar a página ".get(page)."/".get(id)." inexistente");
?>

<div id="conteudo">
<h3>Ops! endereço incorreto =(</h3><hr>
Não conseguimos encontrar está página, volte para o <a href="<?=raiz;?>inicio/">início.</a><br>
		</div>