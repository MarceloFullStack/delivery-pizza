<?php
$cheque = "1";
$cre_americanexpress = "1";
$cre_diners = "1";
$cre_elo = "1";
$cre_hiper = "1";
$cre_master = "1";
$cre_visa = "1";
$deb_dinersinter = "1";
$deb_elo = "1";
$deb_hiper = "1";
$deb_master = "1";
$deb_visaelectron = "1";
$dinheiro = "1";
$paypal = "1";
$vou_aleloalimentacao = "1";
$vou_alelorefeicao = "1";
$vou_sodexoalimentacao = "1";
$vou_sodexorefeicao = "1";
$vou_ticketalimentacao = "1";
$vou_ticketrestaurante = "1";
$vou_vralimentacao = "1";
$vou_vrrefeicao = "1";
?>