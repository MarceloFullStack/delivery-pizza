<?php
$appid="2610406432524275";
include('../bd.php');
//////////////////////////////////////////////////////////////////////////////////////
if($_GET["p"]=="registar_login_fb"){
//////////////////////////////////////////////////////////////////////////////////////
	/*	
	$.post("index.php", { p: "registar_login_fb"
								, id: response.id 
								, name: response.name 
								, g:getCookie("g")
								})
								*/
	//senaotemadd...
	$sql="select * from usuarios where id_logado='".$_GET["id"]."@fb.com'";
	$result=runSQL($sql);
	while ($row = mysql_fetch_array($result)) {
		$rs[]=$row;
	}
	$achou=0;
	for($i=0;$i<=(count($rs)-1);$i++){
		$achou=1;
		$sql="update usuarios set senha='".$_GET["g"]."' where  id_logado='".$_GET["id"]."@fb.com' ";
		runSQL($sql);
		break;
	}
	if($achou==0){
		$sql="
						
				INSERT INTO `usuarios` (
				 `nome`
				, `email`
				, `senha`
				, `telefone`
				, `celular`
				, `cidade`
				, `bairro`
				, `endereco`
				, `complemento`
				, `numero`
				, `data`
				, `id_logado`
				, `latitude`
				, `longitude`
				, `cpf`) 
				 VALUES 

					('".$_GET["name"]."', '', '".$_GET["g"]."'
						, ''						/*telefone*/
						, ''						/*celular*/
						, ''						/*cidade*/
						, ''						/*bairro*/
						, ''						/*endereco*/
						, ''						/*complemento*/
						, '0'						/*numero*/
						, ''						/*data*/
						, '".$_GET["id"]."@fb.com'						/*id_logado*/
						, ''						/*latitude*/
						, ''						/*longitude*/
						, '')						/*undefined*/
						
						
					";
		runSQL($sql);
	}
	exit;
}
$conf=mysql_query("SELECT * FROM config");
$config=mysql_fetch_assoc($conf);
?>
<body onload="checkLoginState()" bgcolor="#F5F5F5">
<table width="100%" height="100%"><tr><td align="center" valign="center">
	<img src="../admin/logo/<?php echo $config['logomarca']; ?>">
</table>
<script>
function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  var expires = "expires="+ d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
</script>
<script>
function statusChangeCallback(response) {
    console.log('statusChangeCallback');
    console.log(response);
    // The response object is returned with a status field that lets the
    // app know the current login status of the person.
    // Full docs on the response object can be found in the documentation
    // for FB.getLoginStatus().
    if (true/*response.status === 'connected'*/) {
      // Logged into your app and Facebook.
	  <?php
	  if(false/*$_GET["logout"]==1*/){
	  ?>
			FB.logout(function(response) {
                location.href="facebook.com";
            });	  
	  <?
	  }else{
	  ?>
		testAPI();
	  <?php
	  }
	  ?>
    } else {
	  <?php
	  if($_GET["logout"]==1){
	  ?>
			FB.logout(function(response) {
                location.href="facebook.com";
            });	  
	  <?
	  }
	  ?>
    }
  }
  
function testAPI() {
	/**/
    //console.log('Welcome!  Fetching your information.... ');
		  token=location.href.split("access_token=")[1];
		  if(token.indexOf("&")!=-1){
			  token=token.split("&")[0];
		  }
    FB.api('/me', function(response) {
    //FB.api('/email?access_token='+token, function(response) {
      //console.log('Successful login for: ' + response.name);
      //document.getElementById('status').innerHTML =
        //'Thanks for logging in, ' + response.name + '!<br><img src="http://graph.facebook.com/'+response.id+'/picture?type=square">';
		//console.log(response);
		//document.body.innerHTML='<a href="http://graph.facebook.com/'+response.id+'"><img src="http://graph.facebook.com/'+response.id+'/picture?type=square"></a>';
		//alert(location.href);
		  token=location.href.split("access_token=")[1];
		  if(token.indexOf("&")!=-1){
			  token=token.split("&")[0];
			  
		  }
		//location.href='http://graph.facebook.com/'+response.id+'?access_token='+token;
		//location.href='http://facebook.com/'+response.id+'';
		//location.href='http://graph.facebook.com/'+response.id+'/picture?type=normal';
		//location.href="http://graph.facebook.com/"+response.id+"?access_token="+token;
		//location.href="https://facebook.com/profile.php?id="+response.id;
		/*
		  var xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			 //document.getElementById("demo").innerHTML = this.responseText;
			 //alert(this.responseText);
			}
		  };
		  s="";
		  s+="&id="+escape(response.id);
		  s+="&name="+escape(response.name);
		  s+="&g="+escape(getCookie("g"));
		  xhttp.open("GET", "index.php?p=registar_login_fb"+s, true);
		  xhttp.send();
		  */
		
		
    });/**/
}  

  window.fbAsyncInit = function() {
    FB.init({
      appId      : '<?=$appid?>',
      cookie     : true,
      xfbml      : true,
      version    : 'v2.8'
    });
    FB.AppEvents.logPageView();   
	

	
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

<script>
function checkLoginState() {
  FB.getLoginStatus(function(response) {
	  statusChangeCallback(response);
      //statusChangeCallback(response);
	  
  });
  if(location.href.indexOf("access_token=")!=-1){
	  //alert(location.href);
	  token=location.href.split("access_token=")[1];
	  if(token.indexOf("&")!=-1){
		  token=token.split("&")[0];
	  }
	  <?php
	  
	  session_start();
	  if($_GET["logout"]==1 && $_SESSION["logout"]!=1){
		  $_SESSION["logout"]=1;
	  }else if($_GET["logout"]==1 && $_SESSION["logout"]==1){
		  //$_SESSION["logout"]="";
	  ?>
			FB.logout(function(response) {
                location.href="facebook.com";
            });	  
	  <?php
	  }else{
	  ?>
		  	//if(localStorage.getItem("ios")+""=="s"){
			  //location.href="../fb2/?token="+token+"&ios=s";
			//}else{
			  location.href="../fb2/?token="+token+"";
			//}

	  <?php
	  }
	  ?>
  }
}
</script>
<script>
function VAI_PRO_LOGIN(){
	<?php
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
	?>
	setCookie("g", "<?=$_GET["g"]?>", 30);

		var uri = encodeURI('<?=$actual_link?>/fb');
		window.location = encodeURI("https://www.facebook.com/dialog/oauth?client_id=<?=$appid?>&redirect_uri="+uri+"&response_type=token");
		// The person is not logged into your app or we are unable to tell.
		//document.getElementById('status').innerHTML = 'Please log ' +
																//'into this app.';

}
</script>

<!--
<input onclick="VAI_PRO_LOGIN()" type="button" value="FACE">
<fb:login-button 
  scope="public_profile,email"
  onlogin="checkLoginState();">
</fb:login-button>
-->

<?php
if($_GET["init"]==1){
?>
	<?php
	if($_GET["ios"]=="s"){
	?>
	<script>
	localStorage.setItem("ios","s");
	</script>
	<?php	
	}
	?>
	<script>
	VAI_PRO_LOGIN();
	</script>
<?php
}
?>

</body>