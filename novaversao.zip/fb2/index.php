<?php
session_start();
include('../bd.php');
function get_basic_info($id) {
    $url = 'https://graph.facebook.com/' . $id."/picture?type=square";
    //$info = json_decode(file_get_contents($url), true);
								$ch = curl_init($url);

								$fp = fopen("download", "wb");

								curl_setopt($ch, CURLOPT_FILE, $fp);
								curl_setopt($ch, CURLOPT_HEADER, 0);
								curl_exec($ch);
								curl_close($ch);
								fclose($fp);
	$info=file("download");
	$info=implode("",$info);
    return $info;
}
	//$result=runSQL("select * from usuarios /*where senha='".$_POST["g"]."'*/");
	//while ($row = mysql_fetch_array($result)) {
		//$rs[]=$row;
	//}
	//var_dump($rs);
	//exit;

require_once __DIR__ . '/vendor/autoload.php'; // change path as needed

$fb = new \Facebook\Facebook([
  'app_id' => '2610406432524275',   
  'app_secret' => '99bc066108bb405110cc10f8afc09052'
  ,'default_graph_version' => 'v2.10'
  //'default_access_token' => '{access-token}', // optional
]);

// Use one of the helper classes to get a Facebook\Authentication\AccessToken entity.
   $helper = $fb->getRedirectLoginHelper();
   $permissions=['email'];
   //var_dump($helper);
   //exit;
//   $helper = $fb->getJavaScriptHelper();
//   $helper = $fb->getCanvasHelper();
//   $helper = $fb->getPageTabHelper();
$response = null;
try {
  // Get the \Facebook\GraphNodes\GraphUser object for the current user.
  // If you provided a 'default_access_token', the '{access-token}' is optional.
  //$response = $fb->get('/me?fields=id,name,email', $_GET["token"]);
  //$response = $fb->get('/me',$_GET["token"],['fields' => 'id,name,email,address,first_name,last_name']);
  //$response = $fb->get('/me/feed',$_GET["token"]);
  //$response = $fb->get('/me',$_GET["token"]);
  
  //$response = $fb->get('/10215240858310521',$_GET["token"]);
  $response = $fb->get('/me?fields=id,name,email,birthday,gender,first_name,last_name,picture,education,work',$_GET["token"]);
  /*
	$response = $fb->get(
		'/10215240858310521',
		array (
		  'fields' => 'birthday','email','hometown'
		),
		$_GET["token"]
	  );  */
  
  
} catch(\Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(\Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}
//if($_GET["logout"]==1){
	//var_dump($response);
//}
//$graphNode = $response->getGraphNode();

//$loginUrl=$helper->getLoginUrl($url_login,$permissions);
$me = $response->getGraphUser();
//var_dump(get_basic_info($me->getId()));
//exit;
//var_dump($response);
//exit;

//echo 'Logged in as ' . $me->getName().'<br>'.$me->getId();
?>
<script>
function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
	if (this.readyState == 4 && this.status == 200) {
	 //document.getElementById("demo").innerHTML = this.responseText;
	 //alert(this.responseText);
	}
};
s="";
s+="&id="+escape("<?=$me->getId()?>");
s+="&name="+escape("<?=$me->getName()?>");
s+="&g="+escape(getCookie("g"));
xhttp.open("GET", "../fb/index.php?p=registar_login_fb"+s, true);
xhttp.send();
</script>