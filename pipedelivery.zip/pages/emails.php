<?php
// envio de emails
$c4_cadastro = "1";
$c4_cadastro2 = "1";;
$c4_pedido = "1";
$c4_pedido2 = "1";
$c4_senha = "1";
$c4_senha2 = "1";
$c4_dados = "1";
$c4_dados2 = "1";
$c4_status = "1";
$c4_status2 = "1";
?>