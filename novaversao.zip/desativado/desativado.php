<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #F5F5F5;
}
.box1 {
	float: left;
	width: 100%;
	background-image: url(cropped-cropped-cropped-icon_43764.png);
	background-repeat: no-repeat;
	background-position: center 130px;
	height: 500px;
	text-align: center;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 30px;
	font-weight: bold;
	color: #666666;
	padding-top: 400px;
}
.box1 span {
	color: #666666;
	font-size: 20px;
	line-height: 40px;
}
-->
</style>
</head>

<body>
<div class="box1">Ops !! Site temporariamente fora do ar.<br />
<span>Entre em contato com seu Representante Comercial</span>.</div>
</body>
</html>
