﻿<?php

$bg = "1";
$cartao = "1";
                 
$cfg = array("empresa" => "Pipe Delivery",               // NOME DA EMPRESA
	 "email"    => "sac.phplivre@gmail.com",              // EMAIL DE CONTATO
     "site"    => "http://www.phplivre.com",              // SITE DA EMPRESA
	"facebook" => "https://www.facebook.com/desenvolvimentowebemgeral",             // FACEBOOK DA EMPRESA
	"minimo" => "10.00",                            // VALOR DO PEDIDO MINIMO
	"dias_func" => "Quarta à Domingo das 18:00 às 00:00.",                         // DIAS DE FUNCIONAMENTO
	"tel1" => "(12) 0000-0000",                // TELEFONE 1
	"tel2" => "(12) 0000-0000",              // TELEFONE 2
	"endereco" => "Rua João Souza, 00",          // ESTADO E CIDADE
	"endereco2" => "São José dos Campos, SP",        // RUA E NUMERO
	"regulamento" => "Ao realizar pedidos em nosso site, você concorda com o regulamento.<br>
<br>
1 - Não efetuamos cancelamento após 15min do realizamento do pedido.<br>
2 - Cobramos taxas para entregas.<br>
3 - Cobramos taxas no caso de trocas.<br>
<br>
<b>Qualquer dúvida, estamos a disposição.</b>",                // REGULAMENTO DOS PEDIDOS
	"iphone" => "http://www.phplivre.com/#",              // LINK DO APP IPHONE
	"android" => "http://www.phplivre.com/#",          // LINK DO APP ANDROID
	"link_loja" => "http://http://www.phplivre.com/",        // LINK DA LOJA
    "pagto_on" => "1",        // ACEITAR PAGAMENTOS ONLINE
    "tempo_e" => "30 min",        // TEMPO ESTIMADO PARA ENTREGA
    "atualizacao" => "1",        // INFORMAR SOBRE ATUALIZAÇÕES
    "agendamento" => "1",        // PERMITIR AGENDAMENTO DE ENTREGAS
    "vcep" => "1"        // VERIFICAR CEPS
	 );
?>



