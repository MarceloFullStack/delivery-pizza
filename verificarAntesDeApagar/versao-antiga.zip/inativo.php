﻿<?php

include('bd.php');


$conf=mysql_query("SELECT * FROM config");

$config=mysql_fetch_assoc($conf);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="https://www.w3.org/1999/xhtml">

<head>

<meta https-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Site Inativo</title>

<link rel="stylesheet" media="(min-width: 640px)" href="css/home.css">

</head>



<body>

<div class="box2017">

  <div class="box2018"><a href="/"><img src="/admin/logo/<?php echo $config['logomarca']; ?>" style="width: 233px;"/></a></div>

  <div class="box2019">Site Inativo</div>
  <a href="install"><div class="box2019" style="width: auto; font-size: 54px; color: #d62020;">Clique aqui para <br>Instalar Banco de Dados</div></a>

</div>

</body>

</html>

