
function SEND_MSG(s){
  if(location.href.indexOf("/AppDesigner/")!=-1){
   parent.document.getElementById("LAST_MSG").value=s;
   parent.CHANGE_LAST_MSG();
  }else{
      if(window['os_tipo']=='ios'){
          window["ios_msg"]=s;
      }else{
          alert(s);
      }
  }
}
function THE_EVAL(s){
   eval(s);
}
            $( document ).ready(function() {
              if(location.href.indexOf("/AppDesigner/")!=-1){
                eval(parent.document.getElementById("LISTA2_RESP").value);
              }
            });
