<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="https://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>

<link href="css/home.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js/home.js"></script>

</head>



<body>

<div class="box34" id="sabores_4_right_top" style="display:none;">

  <div class="box35">Selecione um Sabor - <title></title></div>

  <div class="box36">Pizzas Salgadas</div>

  

  <div class="box37" data-pedaco="2">

    <div class="box38"><img src="arquivos/produto_2429.jpg" width="40" height="40" /></div>

    <div class="box39">

      <div class="box40">Atum - R$33,00</div>

      <div class="box41">Atum, Cebola, Mussarela, Orégano</div>

    </div>

  </div>

  

  

  <div class="box37">

    <div class="box38"><img src="arquivos/produto_2429.jpg" width="40" height="40" /></div>

    <div class="box39">

      <div class="box40">Baiana - R$33,00</div>

      <div class="box41">Atum, Cebola, Mussarela, Orégano</div>

    </div>

  </div>

  <div class="box37">

    <div class="box38"><img src="arquivos/produto_2429.jpg" width="40" height="40" /></div>

    <div class="box39">

      <div class="box40">Calabreza com Bacon - R$33,00</div>

      <div class="box41">Atum, Cebola, Mussarela, Orégano</div>

    </div>

  </div>

  <div class="box37">

    <div class="box38"><img src="arquivos/produto_2429.jpg" width="50" height="50" /></div>

    <div class="box39">

      <div class="box40">Atum - R$33,00</div>

      <div class="box41">Atum, Cebola, Mussarela, Orégano</div>

    </div>

  </div>

</div>

</body>

</html>

