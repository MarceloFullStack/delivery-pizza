EasyInstaller = function () {

};

EasyInstaller._MSG = {};
EasyInstaller._MSG["ajax_connection_error"] = "AJAX: kann nicht auf dem Server oder Server antwort verbinden! Bitte versuchen Sie es sp�ter erneut.";
EasyInstaller._MSG["db_version"] = "DB-Version";
EasyInstaller._MSG["error"] = "Fehler!";
EasyInstaller._MSG["success"] = "Erfolg!";
EasyInstaller._MSG["connection_was_established"] = "Eine Verbindung wurde erfolgreich mit dem Server hergestellt.";
EasyInstaller._MSG["connection_error"] = "Falsche Parameter �bergeben oder Verbindungsfehler!";

