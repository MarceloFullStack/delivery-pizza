<?php
$agdata1 = "De Quarta a Domingo";
$agdata1_horarios = "18:00,19:00,20:00,21:00,22:00,23:00,00:00";

$agdata2 = "";
$agdata2_horarios = "";

$agdata3 = "";
$agdata3_horarios = "";

$agdata4 = "";
$agdata4_horarios = "";

$agdata5 = "";
$agdata5_horarios = "";

$agdata6 = "";
$agdata6_horarios = "";

$agdata7 = "Entrega imediata, Retirada na loja, Retirada no balcão";
$agdata7_horarios = "";

$agdata_outros = "Entrega imediata, Retirada no balcão";
?>
